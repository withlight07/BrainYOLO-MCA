import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from timm.layers import trunc_normal_, DropPath, to_2tuple

# https://arxiv.org/pdf/2412.14598


layer_scale = True
init_value = 1e-6          #3月23日  层缩放参数  层缩放因子的默认值为1e-06

class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        # 深度可分离卷积，输入输出通道数都为 dim，卷积核大小为 3，步长为 1，填充为 1，使用分组卷积，分组数等于通道数
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x, H, W):
        B, N, C = x.shape
        # 将输入张量的形状从 (B, N, C) 转换为 (B, C, H, W)
        x = x.transpose(1, 2).view(B, C, H, W)
        # 进行深度可分离卷积操作
        x = self.dwconv(x)
        # 将结果展平为 (B, N, C) 的形状
        x = x.flatten(2).transpose(1, 2)

        return x


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        # 计算每个头的维度
        head_dim = dim // num_heads
        # 计算缩放因子，默认为 head_dim 的平方根的倒数
        self.scale = qk_scale or head_dim ** -0.5
        # 线性层将输入映射到 qkv 向量
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        # 注意力 dropout 层
        self.attn_drop = nn.Dropout(attn_drop)
        # 输出线性层
        self.proj = nn.Linear(dim, dim)
        # 投影 dropout 层
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, N, C = x.shape
        # 将输入通过 qkv 线性层并重塑形状，分离出 q, k, v
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        # 计算注意力矩阵，使用缩放因子
        attn = (q @ k.transpose(-2, -1)) * self.scale
        # 对注意力矩阵进行 softmax 归一化
        attn = attn.softmax(dim=-1)
        # 应用注意力 dropout
        attn = self.attn_drop(attn)
        # 计算注意力结果
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        # 通过输出线性层
        x = self.proj(x)
        # 应用投影 dropout
        x = self.proj_drop(x)
        return x


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        # 输出特征维度，默认为输入特征维度
        out_features = out_features or in_features
        # 隐藏层特征维度，默认为输入特征维度
        hidden_features = hidden_features or in_features
        # 第一个线性层
        self.fc1 = nn.Linear(in_features, hidden_features)
        # 深度可分离卷积
        self.dwconv = DWConv(hidden_features)
        # 激活函数
        self.act = act_layer()
        # 第二个线性层
        self.fc2 = nn.Linear(hidden_features, out_features)
        # dropout 层
        self.drop = nn.Dropout(drop)
        # 初始化权重
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            # 截断正态分布初始化线性层权重
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                # 初始化线性层偏置为 0
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            # 初始化 LayerNorm 层的偏置为 0
            nn.init.constant_(m.bias, 0)
            # 初始化 LayerNorm 层的权重为 1
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            # 计算卷积层的 fan_out
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            # 正态分布初始化卷积层权重
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                # 初始化卷积层偏置为 0
                m.bias.data.zero_()

    def forward(self, x, H, W):
        # 第一个线性变换
        x = self.fc1(x)
        # 深度可分离卷积操作
        x = self.dwconv(x, H, W)
        # 激活函数
        x = self.act(x)
        # dropout
        x = self.drop(x)
        # 第二个线性变换
        x = self.fc2(x)
        # dropout
        x = self.drop(x)
        return x


def block(x, h,w):
    B, H, W, C = x.shape
    # 计算高度和宽度需要填充的大小，使能被 block_size 整除
    pad_h = (h - H % h) % h
    pad_w = (w - W % w) % w
    if pad_h > 0 or pad_w > 0:
        # 对输入进行填充
        x = F.pad(x, (0, 0, 0, pad_w, 0, pad_h))
    Hp, Wp = H + pad_h, W + pad_w
    # 重塑输入张量形状，进行分块操作
    x = x.reshape(B, Hp // h, h, Wp // w, w, C)
    # 重新排列维度
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous()
    return x, H, Hp,Wp, C


def unblock(x, Ho):
    B, H, W, win_H, win_W, C = x.shape
    # 重新排列维度
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().reshape(B, H * win_H, W * win_W, C)
    Wp = Hp = H * win_H
    Wo = Ho
    if Hp > Ho or Wp > Wo:
        # 截取输出张量
        x = x[:, :Ho, :Wo, :].contiguous()
    return x


def alter_sparse(x, sparse_size=8):
    # 重新排列维度
    x = x.permute(0, 2, 3, 1)
    # 检查输入尺寸是否能被稀疏块大小整除
    assert x.shape[1] % sparse_size == 0 and x.shape[2] % sparse_size == 0, 'image size should be divisible by block_size'
    grid_size_h = x.shape[1] // sparse_size

    grid_size_w = x.shape[2] // sparse_size
    # 分块操作
    out, H, Hp,Wp, C = block(x, grid_size_h,grid_size_w)
    # 重新排列维度
    out = out.permute(0, 3, 4, 1, 2, 5).contiguous()
    # 重塑形状
    out = out.reshape(-1, sparse_size, sparse_size, C)
    # 重新排列维度
    out = out.permute(0, 3, 1, 2)
    return out, H, Hp, Wp, C


def alter_unsparse(x, H, Hp, Wp, C, sparse_size=8):
    # 重新排列维度
    x = x.permute(0, 2, 3, 1)
    # 重塑形状
    x = x.reshape(-1, Hp // sparse_size, Wp // sparse_size, sparse_size, sparse_size, C)
    # 重新排列维度
    x = x.permute(0, 3, 4, 1, 2, 5).contiguous()
    # 合并块
    out = unblock(x, H)
    # 重新排列维度
    out = out.permute(0, 3, 1, 2)
    return out


class SABlock(nn.Module):
    def __init__(self, dim, num_heads=4, sparse_size=2, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        # 位置编码，使用卷积实现
        self.pos_embed = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        # 归一化层
        self.norm1 = norm_layer(dim)
        # 注意力模块
        self.attn = Attention(
            dim,
            num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop)
        # 随机深度层
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        # 归一化层
        self.norm2 = norm_layer(dim)
        # 计算 MLP 的隐藏层维度
        mlp_hidden_dim = int(dim * mlp_ratio)
        # MLP 模块
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        global layer_scale
        self.ls = layer_scale
        self.sparse_size = sparse_size
        if self.ls:
            global init_value
            print(f"Use layer_scale: {layer_scale}, init_values: {init_value}")
            # 可学习参数 gamma_1
            self.gamma_1 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)
            # 可学习参数 gamma_2
            self.gamma_2 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)


    def forward(self, x):
        # 存储输入张量的原始形状
        # x_befor = x.flatten(2).transpose(1, 2)
        B, N, H, W = x.shape

        pad_H = (self.sparse_size - H % self.sparse_size) % self.sparse_size
        pad_W = (self.sparse_size - W % self.sparse_size) % self.sparse_size

        # 如果需要填充，则进行填充
        if pad_H > 0 or pad_W > 0:
            x = F.pad(x, (0, pad_W, 0, pad_H), mode='constant', value=0)
            B_, N_, H_, W_ = x.shape
        else:
            B_, N_, H_, W_ = x.shape

        x_befor = x.flatten(2).transpose(1, 2)

        if self.ls:
            # 稀疏化操作
            x, Ho, Hp,Wp, C = alter_sparse(x, self.sparse_size)
            Bf, Nf, Hf, Wf = x.shape
            # 重塑形状
            x = x.flatten(2).transpose(1, 2)
            # 注意力操作
            x = self.attn(self.norm1(x))
            # 重塑形状
            x = x.transpose(1, 2).reshape(Bf, Nf, Hf, Wf)
            # 反稀疏化操作
            x = alter_unsparse(x, Ho, Hp, Wp, C, self.sparse_size)
            # 重塑形状
            x = x.flatten(2).transpose(1, 2)
            # 使用可学习参数 gamma_1 进行残差连接
            x = x_befor + self.drop_path(self.gamma_1 * x)
            # MLP 操作并使用可学习参数 gamma_2 进行残差连接
            x = x + self.drop_path(self.gamma_2 * self.mlp(self.norm2(x),H_, W_))
        else:
            # 稀疏化操作
            x, Ho, Hp, C = alter_sparse(x, self.sparse_size)
            Bf, Nf, Hf, Wf = x.shape
            # 重塑形状
            x = x.flatten(2).transpose(1, 2)
            # 注意力操作
            x = self.attn(self.norm1(x))
            # 重塑形状
            x = x.transpose(1, 2).reshape(Bf, Nf, Hf, Wf)
            # 反稀疏化操作
            x = alter_unsparse(x, Ho, Hp, C, self.sparse_size)
            # 重塑形状
            x = x.flatten(2).transpose(1, 2)
            # 残差连接
            x = x_befor + self.drop_path(x)
            # MLP 操作和残差连接
            x = x + self.drop_path(self.mlp(self.norm2(x), H_, W_))



        # 重塑形状为原始输入形状
        x = x.transpose(1, 2).reshape(B, N, H_, W_)

        # 如果进行了填充，去除填充部分
        if pad_H > 0 or pad_W > 0:
            x = x[:, :, :H, :W]
        return x



class PSABloc_SABlock(nn.Module):
    """
    PSABlock class implementing a Position-Sensitive Attention block for neural networks.

    This class encapsulates the functionality for applying multi-head attention and feed-forward neural network layers
    with optional shortcut connections.

    Attributes:
        attn (Attention): Multi-head attention module.
        ffn (nn.Sequential): Feed-forward neural network module.
        add (bool): Flag indicating whether to add shortcut connections.

    Methods:
        forward: Performs a forward pass through the PSABlock, applying attention and feed-forward layers.

    Examples:
        Create a PSABlock and perform a forward pass
        >>> psablock = PSABlock(c=128, attn_ratio=0.5, num_heads=4, shortcut=True)
        >>> input_tensor = torch.randn(1, 128, 32, 32)
        >>> output_tensor = psablock(input_tensor)
    """

    def __init__(self, c, attn_ratio=0.5, num_heads=4, shortcut=True) -> None:
        """Initializes the PSABlock with attention and feed-forward layers for enhanced feature extraction."""
        super().__init__()

        self.attn = SABlock(c)
        self.ffn = nn.Sequential(Conv(c, c * 2, 1), Conv(c * 2, c, 1, act=False))
        self.add = shortcut

    def forward(self, x):
        """Executes a forward pass through PSABlock, applying attention and feed-forward layers to the input tensor."""
        x = x + self.attn(x) if self.add else self.attn(x)
        x = x + self.ffn(x) if self.add else self.ffn(x)
        return x

def autopad(k, p=None, d=1):  # kernel, padding, dilation
    """Pad to 'same' shape outputs."""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    """Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)."""

    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """Initialize Conv layer with given arguments including activation."""
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """Apply convolution, batch normalization and activation to input tensor."""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """Perform transposed convolution of 2D data."""
        return self.act(self.conv(x))


class C2PSA_SABlock(nn.Module):
    """
    C2PSA module with attention mechanism for enhanced feature extraction and processing.

    This module implements a convolutional block with attention mechanisms to enhance feature extraction and processing
    capabilities. It includes a series of PSABlock modules for self-attention and feed-forward operations.

    Attributes:
        c (int): Number of hidden channels.
        cv1 (Conv): 1x1 convolution layer to reduce the number of input channels to 2*c.
        cv2 (Conv): 1x1 convolution layer to reduce the number of output channels to c.
        m (nn.Sequential): Sequential container of PSABlock modules for attention and feed-forward operations.

    Methods:
        forward: Performs a forward pass through the C2PSA module, applying attention and feed-forward operations.

    Notes:
        This module essentially is the same as PSA module, but refactored to allow stacking more PSABlock modules.

    Examples:
        >>> c2psa = C2PSA(c1=256, c2=256, n=3, e=0.5)
        >>> input_tensor = torch.randn(1, 256, 64, 64)
        >>> output_tensor = c2psa(input_tensor)
    """

    def __init__(self, c1, c2, n=1, e=0.5):
        """Initializes the C2PSA module with specified input/output channels, number of layers, and expansion ratio."""
        super().__init__()
        assert c1 == c2
        self.c = int(c1 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv(2 * self.c, c1, 1)

        self.m = nn.Sequential(*(PSABloc_SABlock(self.c, attn_ratio=0.5, num_heads=self.c // 64) for _ in range(n)))

    def forward(self, x):
        """Processes the input tensor 'x' through a series of PSA blocks and returns the transformed tensor."""
        a, b = self.cv1(x).split((self.c, self.c), dim=1)
        b = self.m(b)
        return self.cv2(torch.cat((a, b), 1))



if __name__ =='__main__':

    sa_block=SABlock(128)
    x=torch.randn(1, 128, 7, 21)
    output = sa_block(x)
    print("0utput shape:",output.shape)